<?php get_header() ?>

<div id="content_index">
<!-- #ici code -->
</div>
<?php get_footer() ?>